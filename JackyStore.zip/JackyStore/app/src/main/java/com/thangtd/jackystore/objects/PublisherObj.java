package com.thangtd.jackystore.objects;

public class PublisherObj {
    public String name;

    public PublisherObj() {
    }

    public PublisherObj(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
