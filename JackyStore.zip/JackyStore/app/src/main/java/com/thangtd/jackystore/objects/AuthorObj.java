package com.thangtd.jackystore.objects;

public class AuthorObj {
    public String name;

    public AuthorObj(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
